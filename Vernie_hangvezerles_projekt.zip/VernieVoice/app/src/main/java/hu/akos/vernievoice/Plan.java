package hu.akos.vernievoice;

import java.util.Collections;
import java.util.List;

final class Plan {
    enum Type { DRIVE, TURN, WAIT }

    static final class Step {
        final Type type;
        final int speed;
        final long durationMs;

        Step(Type type, int speed, long durationMs) {
            this.type = type;
            this.speed = speed;
            this.durationMs = durationMs;
        }
    }

    final boolean accepted;
    final String message;
    final List<Step> steps;

    Plan(boolean accepted, String message, List<Step> steps) {
        this.accepted = accepted;
        this.message = message == null ? "" : message;
        this.steps = Collections.unmodifiableList(steps);
    }
}
