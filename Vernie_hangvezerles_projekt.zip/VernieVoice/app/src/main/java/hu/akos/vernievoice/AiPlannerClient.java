package hu.akos.vernievoice;

import android.os.Handler;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class AiPlannerClient {
    interface Callback { void onSuccess(Plan plan); void onError(String message); }
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler;

    AiPlannerClient(Handler mainHandler) { this.mainHandler = mainHandler; }

    boolean isConfigured() {
        return BuildConfig.VERNIE_BACKEND_URL.startsWith("https://") && !BuildConfig.VERNIE_DEVICE_TOKEN.isEmpty();
    }

    void plan(String command, Callback callback) {
        if (!isConfigured()) { callback.onError("A természetes nyelvű vezérlés háttérszolgáltatása még nincs beállítva."); return; }
        executor.execute(() -> request(command, callback));
    }

    void shutdown() { executor.shutdownNow(); }

    private void request(String command, Callback callback) {
        HttpURLConnection connection = null;
        try {
            byte[] body = new JSONObject().put("command", command).toString().getBytes(StandardCharsets.UTF_8);
            if (body.length > 2048) throw new IOException("A parancs túl hosszú.");
            connection = (HttpURLConnection) new URL(BuildConfig.VERNIE_BACKEND_URL).openConnection();
            connection.setConnectTimeout(8_000);
            connection.setReadTimeout(20_000);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Authorization", "Bearer " + BuildConfig.VERNIE_DEVICE_TOKEN);
            connection.setDoOutput(true);
            try (OutputStream output = connection.getOutputStream()) { output.write(body); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String response = readLimited(stream, 32_768);
            if (code < 200 || code >= 300) throw new IOException("A tervező hibát jelzett (" + code + ").");
            Plan plan = PlanValidator.parse(response);
            mainHandler.post(() -> callback.onSuccess(plan));
        } catch (Exception error) {
            mainHandler.post(() -> callback.onError("Nem tudtam értelmezni a feladatot: " + error.getMessage()));
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String readLimited(InputStream input, int limit) throws IOException {
        if (input == null) return "";
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[2048];
        int total = 0;
        int count;
        while ((count = input.read(buffer)) != -1) {
            total += count;
            if (total > limit) throw new IOException("Túl nagy válasz.");
            output.write(buffer, 0, count);
        }
        return output.toString(StandardCharsets.UTF_8.name());
    }
}
