package hu.akos.vernievoice;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.ViewGroup;
import android.widget.*;
import java.text.Normalizer;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PERMISSION_REQUEST = 42;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private LegoMoveHub hub;
    private TaskEngine tasks;
    private AiPlannerClient planner;
    private TextView status;
    private Button listenButton;
    private SpeechRecognizer recognizer;
    private Intent speechIntent;
    private boolean continuousListening;
    private boolean planning;
    private long planningGeneration;
    private String lastImmediate = "";
    private long lastImmediateAt;
    private TextToSpeech speaker;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        hideNavigationBar();
        buildUi();
        hub = new LegoMoveHub(this, new LegoMoveHub.Listener() {
            public void onStatus(String text) { runOnUiThread(() -> status.setText(text)); }
            public void onDisconnected() { runOnUiThread(() -> tasks.connectionLost()); }
        });
        tasks = new TaskEngine(hub, mainHandler, new TaskEngine.Listener() {
            public void onState(String text) { status.setText(text); }
            public void onSpokenMessage(String text) { say(text); }
        });
        planner = new AiPlannerClient(mainHandler);
        setupSpeech();
        speaker = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) speaker.setLanguage(Locale.forLanguageTag("hu-HU"));
        });
        requestNeededPermissions();
    }

    private void buildUi() {
        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(pad, dp(22), pad, dp(30));
        root.setBackground(panelGradient());

        TextView title = text("VERNIE", 36, true);
        title.setTextColor(Color.rgb(225, 255, 248));
        title.setLetterSpacing(0.12f);
        root.addView(title);
        TextView subtitle = text("INTELLIGENS VEZÉRLŐPULT", 13, true);
        subtitle.setTextColor(Color.rgb(74, 222, 190));
        subtitle.setLetterSpacing(0.09f);
        root.addView(subtitle);
        TextView version = text("v0007  •  2026-09-10 20:42 CEST  •  JOYSTICK EDITION", 11, false);
        version.setTextColor(Color.rgb(157, 211, 202));
        version.setGravity(Gravity.CENTER);
        version.setPadding(0, dp(6), 0, 0);
        root.addView(version, matchWrap());
        status = text("Kapcsold be Vernie hubját.", 17, false);
        status.setGravity(Gravity.CENTER);
        status.setTextColor(Color.WHITE);
        status.setBackground(roundedGradient(new int[]{Color.rgb(19, 78, 74), Color.rgb(15, 118, 110)}, 16, Color.rgb(45, 212, 191), 1));
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.setMargins(0, dp(18), 0, dp(12));
        root.addView(status, statusParams);

        Button connect = buttonFor("●  KAPCSOLÓDÁS", () -> {
            invalidatePendingPlan();
            tasks.cancel(false);
            hub.connect();
        });
        connect.setBackground(buttonBackground(Color.rgb(13, 148, 136), Color.rgb(15, 118, 110)));
        root.addView(connect, spacedMatch());
        listenButton = button("◉  HANGVEZÉRLÉS INDÍTÁSA");
        listenButton.setBackground(buttonBackground(Color.rgb(6, 182, 212), Color.rgb(8, 145, 178)));
        listenButton.setOnClickListener(v -> toggleListening());
        root.addView(listenButton, spacedMatch());

        Button emergency = button("⚠  AZONNALI ÁLLJ");
        emergency.setTextSize(23);
        emergency.setTextColor(Color.WHITE);
        emergency.setBackground(buttonBackground(Color.rgb(239, 68, 68), Color.rgb(153, 27, 27)));
        emergency.setMinHeight(dp(72));
        emergency.setOnClickListener(v -> emergencyPause());
        root.addView(emergency, spacedMatch());

        TextView manual = text("KÉZI VEZÉRLÉS", 14, true);
        manual.setTextColor(Color.rgb(153, 246, 228));
        manual.setLetterSpacing(0.08f);
        manual.setPadding(0, dp(18), 0, dp(8));
        root.addView(manual);
        JoystickView joystick = new JoystickView();
        root.addView(joystick, new LinearLayout.LayoutParams(dp(260), dp(260)));
        TextView joyHelp = text("Húzd a kart a kívánt irányba • Elengedésre megáll", 12, false);
        joyHelp.setTextColor(Color.rgb(153, 211, 203));
        joyHelp.setGravity(Gravity.CENTER);
        joyHelp.setPadding(0, dp(6), 0, dp(12));
        root.addView(joyHelp, matchWrap());

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button resume = buttonFor("▶  FOLYTATÁS", this::resumeTask);
        resume.setBackground(buttonBackground(Color.rgb(16, 185, 129), Color.rgb(5, 150, 105)));
        Button cancel = buttonFor("■  TÖRLÉS", this::cancelTask);
        cancel.setBackground(buttonBackground(Color.rgb(71, 85, 105), Color.rgb(51, 65, 85)));
        LinearLayout.LayoutParams leftWeight = weighted();
        leftWeight.setMargins(0, 0, dp(5), 0);
        LinearLayout.LayoutParams rightWeight = weighted();
        rightWeight.setMargins(dp(5), 0, 0, 0);
        row.addView(resume, leftWeight);
        row.addView(cancel, rightWeight);
        root.addView(row, matchWrap());

        TextView help = text("Mondhatsz szabadon összetett feladatot is. Az „állj”, „szünet”, „folytasd” és „töröld a feladatot” internet nélkül, helyben működik.", 14, false);
        help.setGravity(Gravity.CENTER);
        help.setTextColor(Color.rgb(203, 231, 226));
        help.setPadding(0, dp(16), 0, 0);
        root.addView(help, matchWrap());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }

    private void hideNavigationBar() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideNavigationBar();
    }

    private void setupSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.setText("Ezen a telefonon nem érhető el a hangfelismerés."); return; }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hu-HU");
        speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) { status.setText("Hallgatlak…"); }
            public void onResults(Bundle b) { handleSpeech(b, true); restartListening(); }
            public void onPartialResults(Bundle b) { handleSpeech(b, false); }
            public void onError(int error) { if (continuousListening) restartListening(); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float rms) {}
            public void onBufferReceived(byte[] bytes) {}
            public void onEndOfSpeech() {}
            public void onEvent(int type, Bundle b) {}
        });
    }

    private void handleSpeech(Bundle bundle, boolean finalResult) {
        ArrayList<String> found = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (found == null || found.isEmpty()) return;
        String normalized = normalize(found.get(0));
        if (isPause(normalized)) {
            if (duplicateImmediate("pause")) return;
            emergencyPause();
            return;
        }
        if (!finalResult) return;
        if (normalized.contains("torold") || normalized.contains("felejtsd el")) {
            cancelTask();
            return;
        }
        if (normalized.contains("folytasd") || normalized.equals("tovabb")) {
            resumeTask();
            return;
        }
        if (normalized.trim().isEmpty() || planning) return;
        planning = true;
        long generation = ++planningGeneration;
        status.setText("Értelmezem: „" + found.get(0) + "”…");
        planner.plan(found.get(0), new AiPlannerClient.Callback() {
            public void onSuccess(Plan plan) {
                if (generation != planningGeneration) return;
                planning = false;
                tasks.start(plan);
            }
            public void onError(String message) {
                if (generation != planningGeneration) return;
                planning = false;
                say(message);
            }
        });
    }

    private boolean duplicateImmediate(String command) {
        long now = SystemClock.elapsedRealtime();
        if (command.equals(lastImmediate) && now - lastImmediateAt < 1800) return true;
        lastImmediate = command;
        lastImmediateAt = now;
        return false;
    }

    private void invalidatePendingPlan() {
        planningGeneration++;
        planning = false;
    }

    private void emergencyPause() {
        invalidatePendingPlan();
        tasks.pause();
    }

    private void cancelTask() {
        invalidatePendingPlan();
        tasks.cancel(true);
    }

    private void resumeTask() {
        invalidatePendingPlan();
        tasks.resume();
    }

    private static boolean isPause(String value) {
        return value.matches(".*\\b(allj|stop|szunet|veszallj)\\b.*");
    }

    private void say(String message) {
        status.setText(message);
        if (speaker != null) speaker.speak(message, TextToSpeech.QUEUE_FLUSH, null, "vernie-status");
    }

    private void toggleListening() {
        if (recognizer == null) { say("A hangfelismerés nem érhető el ezen a telefonon."); return; }
        continuousListening = !continuousListening;
        listenButton.setText(continuousListening ? "HANGVEZÉRLÉS LEÁLLÍTÁSA" : "2. HANGVEZÉRLÉS INDÍTÁSA");
        if (continuousListening) recognizer.startListening(speechIntent); else recognizer.cancel();
    }

    private void restartListening() {
        if (continuousListening) mainHandler.postDelayed(() -> {
            if (continuousListening) {
                try { recognizer.startListening(speechIntent); }
                catch (RuntimeException error) { status.setText("A mikrofon újraindítása nem sikerült."); }
            }
        }, 500);
    }

    private void requestNeededPermissions() {
        ArrayList<String> wanted = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) wanted.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) wanted.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) wanted.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) wanted.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!wanted.isEmpty()) requestPermissions(wanted.toArray(new String[0]), PERMISSION_REQUEST);
    }

    private static String normalize(String value) {
        return Normalizer.normalize(value.toLowerCase(Locale.forLanguageTag("hu")), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }
    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        b.setTypeface(null, 1);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setMinHeight(dp(56));
        b.setElevation(dp(7));
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        return b;
    }
    private Button buttonFor(String label, Runnable action) { Button b = button(label); b.setOnClickListener(v -> action.run()); return b; }
    private Button holdButton(String label, int left, int right) {
        Button b = button(label);
        b.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                invalidatePendingPlan();
                tasks.cancel(false);
                if (hub.drive(left, right)) status.setText("Kézi vezérlés — elengedésre megáll.");
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                hub.emergencyStop();
                status.setText("Vernie megállt.");
                view.performClick();
                return true;
            }
            return true;
        });
        return b;
    }
    private TextView text(String value, int size, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); if (bold) t.setTypeface(null, 1); return t; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams spacedMatch() { LinearLayout.LayoutParams p = matchWrap(); p.setMargins(0, dp(5), 0, dp(5)); return p; }
    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private GradientDrawable panelGradient() {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(3, 20, 24), Color.rgb(6, 55, 58), Color.rgb(4, 31, 38)});
        return g;
    }

    private GradientDrawable roundedGradient(int[] colors, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors);
        g.setCornerRadius(dp(radius));
        if (strokeWidth > 0) g.setStroke(dp(strokeWidth), strokeColor);
        return g;
    }

    private StateListDrawable buttonBackground(int top, int bottom) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed},
                roundedGradient(new int[]{darken(bottom), darken(top)}, 15, Color.argb(150, 255, 255, 255), 1));
        states.addState(new int[]{},
                roundedGradient(new int[]{lighten(top), bottom}, 15, Color.argb(115, 255, 255, 255), 1));
        return states;
    }

    private static int lighten(int color) {
        return Color.rgb(Math.min(255, Color.red(color) + 25), Math.min(255, Color.green(color) + 25), Math.min(255, Color.blue(color) + 25));
    }

    private static int darken(int color) {
        return Color.rgb((int)(Color.red(color) * .72f), (int)(Color.green(color) * .72f), (int)(Color.blue(color) * .72f));
    }

    private final class JoystickView extends android.view.View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float knobX;
        private float knobY;
        private float centerX;
        private float centerY;
        private float travel;
        private long lastDriveAt;
        private boolean active;

        JoystickView() {
            super(MainActivity.this);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            setContentDescription("Virtuális irányítókar");
        }

        @Override protected void onSizeChanged(int w, int h, int oldW, int oldH) {
            centerX = w / 2f;
            centerY = h / 2f;
            knobX = centerX;
            knobY = centerY;
            travel = Math.min(w, h) * .31f;
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float outer = Math.min(getWidth(), getHeight()) * .46f;

            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new RadialGradient(centerX - outer * .25f, centerY - outer * .3f, outer * 1.3f,
                    new int[]{Color.rgb(30, 120, 116), Color.rgb(7, 50, 55), Color.rgb(2, 22, 28)}, null, Shader.TileMode.CLAMP));
            paint.setShadowLayer(dp(13), 0, dp(8), Color.argb(190, 0, 0, 0));
            canvas.drawCircle(centerX, centerY, outer, paint);
            paint.clearShadowLayer();

            paint.setShader(null);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(3));
            paint.setColor(Color.rgb(45, 212, 191));
            canvas.drawCircle(centerX, centerY, outer - dp(3), paint);

            paint.setStrokeWidth(dp(1));
            paint.setColor(Color.argb(90, 153, 246, 228));
            canvas.drawCircle(centerX, centerY, travel, paint);
            canvas.drawLine(centerX, centerY - travel, centerX, centerY + travel, paint);
            canvas.drawLine(centerX - travel, centerY, centerX + travel, centerY, paint);

            float knobRadius = Math.min(getWidth(), getHeight()) * .18f;
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new RadialGradient(knobX - knobRadius * .35f, knobY - knobRadius * .4f, knobRadius * 1.5f,
                    new int[]{Color.rgb(153, 246, 228), Color.rgb(20, 184, 166), Color.rgb(6, 95, 94)}, null, Shader.TileMode.CLAMP));
            paint.setShadowLayer(dp(11), 0, dp(7), Color.argb(210, 0, 0, 0));
            canvas.drawCircle(knobX, knobY, knobRadius, paint);
            paint.clearShadowLayer();
            paint.setShader(null);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(Color.argb(190, 225, 255, 248));
            canvas.drawCircle(knobX, knobY, knobRadius - dp(2), paint);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            getParent().requestDisallowInterceptTouchEvent(true);
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
                if (action == MotionEvent.ACTION_DOWN) {
                    invalidatePendingPlan();
                    tasks.cancel(false);
                }
                active = true;
                float dx = event.getX() - centerX;
                float dy = event.getY() - centerY;
                float distance = (float)Math.sqrt(dx * dx + dy * dy);
                if (distance > travel) {
                    dx = dx / distance * travel;
                    dy = dy / distance * travel;
                }
                knobX = centerX + dx;
                knobY = centerY + dy;
                invalidate();

                float x = dx / travel;
                float forward = -dy / travel;
                if (Math.abs(x) < .08f) x = 0;
                if (Math.abs(forward) < .08f) forward = 0;
                int left = Math.round((forward + x) * 60f);
                int right = Math.round((forward - x) * 60f);
                left = Math.max(-60, Math.min(60, left));
                right = Math.max(-60, Math.min(60, right));
                long now = SystemClock.elapsedRealtime();
                if (action == MotionEvent.ACTION_DOWN || now - lastDriveAt >= 55) {
                    if (hub.drive(left, right)) status.setText("Joystick vezérlés — elengedésre megáll.");
                    lastDriveAt = now;
                }
                return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                active = false;
                knobX = centerX;
                knobY = centerY;
                invalidate();
                hub.emergencyStop();
                status.setText("Vernie megállt.");
                performClick();
                getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            }
            return active;
        }

        @Override public boolean performClick() {
            super.performClick();
            return true;
        }
    }

    @Override protected void onStop() {
        invalidatePendingPlan();
        if (tasks != null) tasks.cancel(false);
        super.onStop();
    }

    @Override protected void onDestroy() {
        continuousListening = false;
        mainHandler.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.destroy();
        if (speaker != null) { speaker.stop(); speaker.shutdown(); }
        if (planner != null) planner.shutdown();
        if (hub != null) hub.disconnect();
        super.onDestroy();
    }
}
