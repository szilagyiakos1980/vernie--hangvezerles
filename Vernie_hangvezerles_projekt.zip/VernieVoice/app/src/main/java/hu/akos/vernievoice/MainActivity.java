package hu.akos.vernievoice;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;
import java.text.Normalizer;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PERMISSION_REQUEST = 42;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private LegoMoveHub hub;
    private TaskEngine tasks;
    private AiPlannerClient planner;
    private TextView status;
    private Button listenButton;
    private SpeechRecognizer recognizer;
    private Intent speechIntent;
    private boolean continuousListening;
    private boolean planning;
    private long planningGeneration;
    private String lastImmediate = "";
    private long lastImmediateAt;
    private TextToSpeech speaker;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        hub = new LegoMoveHub(this, new LegoMoveHub.Listener() {
            public void onStatus(String text) { runOnUiThread(() -> status.setText(text)); }
            public void onDisconnected() { runOnUiThread(() -> tasks.connectionLost()); }
        });
        tasks = new TaskEngine(hub, mainHandler, new TaskEngine.Listener() {
            public void onState(String text) { status.setText(text); }
            public void onSpokenMessage(String text) { say(text); }
        });
        planner = new AiPlannerClient(mainHandler);
        setupSpeech();
        speaker = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) speaker.setLanguage(Locale.forLanguageTag("hu-HU"));
        });
        requestNeededPermissions();
    }

    private void buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.rgb(245, 247, 250));

        root.addView(text("VERNIE", 34, true));
        root.addView(text("Magyar, természetes nyelvű hangvezérlés", 17, false));
        status = text("Kapcsold be Vernie hubját.", 17, false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(20), 0, dp(16));
        root.addView(status, matchWrap());

        root.addView(buttonFor("1. KAPCSOLÓDÁS", () -> {
            invalidatePendingPlan();
            tasks.cancel(false);
            hub.connect();
        }), matchWrap());
        listenButton = button("2. HANGVEZÉRLÉS INDÍTÁSA");
        listenButton.setOnClickListener(v -> toggleListening());
        root.addView(listenButton, matchWrap());

        Button emergency = button("AZONNALI ÁLLJ");
        emergency.setTextSize(23);
        emergency.setTextColor(Color.WHITE);
        emergency.setBackgroundColor(Color.rgb(190, 25, 35));
        emergency.setMinHeight(dp(72));
        emergency.setOnClickListener(v -> emergencyPause());
        root.addView(emergency, matchWrap());

        TextView manual = text("Rövid kézi motorpróba", 15, true);
        manual.setPadding(0, dp(16), 0, 0);
        root.addView(manual);
        root.addView(buttonFor("▲  ELŐRE 1 MÁSODPERC", () -> manualPulse(50, 50)), matchWrap());
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(buttonFor("◀ BALRA", () -> manualPulse(-45, 45)), weighted());
        row.addView(buttonFor("JOBBRA ▶", () -> manualPulse(45, -45)), weighted());
        root.addView(row, matchWrap());
        root.addView(buttonFor("▼  HÁTRA 1 MÁSODPERC", () -> manualPulse(-50, -50)), matchWrap());
        root.addView(buttonFor("FOLYTATÁS", this::resumeTask), matchWrap());
        root.addView(buttonFor("FELADAT TÖRLÉSE", this::cancelTask), matchWrap());

        TextView help = text("Mondhatsz szabadon összetett feladatot is. Az „állj”, „szünet”, „folytasd” és „töröld a feladatot” internet nélkül, helyben működik.", 14, false);
        help.setGravity(Gravity.CENTER);
        help.setPadding(0, dp(16), 0, 0);
        root.addView(help, matchWrap());
        setContentView(root);
    }

    private void setupSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.setText("Ezen a telefonon nem érhető el a hangfelismerés."); return; }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hu-HU");
        speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) { status.setText("Hallgatlak…"); }
            public void onResults(Bundle b) { handleSpeech(b, true); restartListening(); }
            public void onPartialResults(Bundle b) { handleSpeech(b, false); }
            public void onError(int error) { if (continuousListening) restartListening(); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float rms) {}
            public void onBufferReceived(byte[] bytes) {}
            public void onEndOfSpeech() {}
            public void onEvent(int type, Bundle b) {}
        });
    }

    private void handleSpeech(Bundle bundle, boolean finalResult) {
        ArrayList<String> found = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (found == null || found.isEmpty()) return;
        String normalized = normalize(found.get(0));
        if (isPause(normalized)) {
            if (duplicateImmediate("pause")) return;
            emergencyPause();
            return;
        }
        if (!finalResult) return;
        if (normalized.contains("torold") || normalized.contains("felejtsd el")) {
            cancelTask();
            return;
        }
        if (normalized.contains("folytasd") || normalized.equals("tovabb")) {
            resumeTask();
            return;
        }
        if (normalized.trim().isEmpty() || planning) return;
        planning = true;
        long generation = ++planningGeneration;
        status.setText("Értelmezem: „" + found.get(0) + "”…");
        planner.plan(found.get(0), new AiPlannerClient.Callback() {
            public void onSuccess(Plan plan) {
                if (generation != planningGeneration) return;
                planning = false;
                tasks.start(plan);
            }
            public void onError(String message) {
                if (generation != planningGeneration) return;
                planning = false;
                say(message);
            }
        });
    }

    private boolean duplicateImmediate(String command) {
        long now = SystemClock.elapsedRealtime();
        if (command.equals(lastImmediate) && now - lastImmediateAt < 1800) return true;
        lastImmediate = command;
        lastImmediateAt = now;
        return false;
    }

    private void invalidatePendingPlan() {
        planningGeneration++;
        planning = false;
    }

    private void emergencyPause() {
        invalidatePendingPlan();
        tasks.pause();
    }

    private void cancelTask() {
        invalidatePendingPlan();
        tasks.cancel(true);
    }

    private void resumeTask() {
        invalidatePendingPlan();
        tasks.resume();
    }

    private static boolean isPause(String value) {
        return value.matches(".*\\b(allj|stop|szunet|veszallj)\\b.*");
    }

    private void manualPulse(int left, int right) {
        invalidatePendingPlan();
        ArrayList<Plan.Step> steps = new ArrayList<>();
        if (left == right) steps.add(new Plan.Step(Plan.Type.DRIVE, left, 1000));
        else steps.add(new Plan.Step(Plan.Type.TURN, left, 700));
        tasks.start(new Plan(true, "", steps));
    }

    private void say(String message) {
        status.setText(message);
        if (speaker != null) speaker.speak(message, TextToSpeech.QUEUE_FLUSH, null, "vernie-status");
    }

    private void toggleListening() {
        if (recognizer == null) { say("A hangfelismerés nem érhető el ezen a telefonon."); return; }
        continuousListening = !continuousListening;
        listenButton.setText(continuousListening ? "HANGVEZÉRLÉS LEÁLLÍTÁSA" : "2. HANGVEZÉRLÉS INDÍTÁSA");
        if (continuousListening) recognizer.startListening(speechIntent); else recognizer.cancel();
    }

    private void restartListening() {
        if (continuousListening) mainHandler.postDelayed(() -> {
            if (continuousListening) {
                try { recognizer.startListening(speechIntent); }
                catch (RuntimeException error) { status.setText("A mikrofon újraindítása nem sikerült."); }
            }
        }, 500);
    }

    private void requestNeededPermissions() {
        ArrayList<String> wanted = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) wanted.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) wanted.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) wanted.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) wanted.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!wanted.isEmpty()) requestPermissions(wanted.toArray(new String[0]), PERMISSION_REQUEST);
    }

    private static String normalize(String value) {
        return Normalizer.normalize(value.toLowerCase(Locale.forLanguageTag("hu")), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }
    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(15); b.setAllCaps(false); return b; }
    private Button buttonFor(String label, Runnable action) { Button b = button(label); b.setOnClickListener(v -> action.run()); return b; }
    private TextView text(String value, int size, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); if (bold) t.setTypeface(null, 1); return t; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override protected void onStop() {
        invalidatePendingPlan();
        if (tasks != null) tasks.cancel(false);
        super.onStop();
    }

    @Override protected void onDestroy() {
        continuousListening = false;
        mainHandler.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.destroy();
        if (speaker != null) { speaker.stop(); speaker.shutdown(); }
        if (planner != null) planner.shutdown();
        if (hub != null) hub.disconnect();
        super.onDestroy();
    }
}
