package hu.akos.vernievoice;

import android.os.Handler;
import android.os.SystemClock;
import java.util.Collections;
import java.util.List;

final class TaskEngine {
    interface Listener {
        void onState(String text);
        void onSpokenMessage(String text);
    }

    private final LegoMoveHub hub;
    private final Handler handler;
    private final Listener listener;
    private List<Plan.Step> steps = Collections.emptyList();
    private int stepIndex;
    private long remainingMs;
    private long stepStartedAt;
    private boolean running;
    private boolean paused;
    private final Runnable stepFinished = this::finishCurrentStep;

    TaskEngine(LegoMoveHub hub, Handler handler, Listener listener) {
        this.hub = hub;
        this.handler = handler;
        this.listener = listener;
    }

    void start(Plan plan) {
        cancel(false);
        if (!plan.accepted) { listener.onSpokenMessage(plan.message); return; }
        if (!hub.isReady()) { listener.onSpokenMessage("Nem tudom elindítani, mert Vernie nincs csatlakoztatva."); return; }
        steps = plan.steps;
        stepIndex = 0;
        remainingMs = steps.get(0).durationMs;
        running = true;
        paused = false;
        if (!plan.message.isEmpty()) listener.onSpokenMessage(plan.message);
        listener.onState("A feladat elindult.");
        startCurrentStep();
    }

    void pause() {
        hub.emergencyStop();
        if (!running) { listener.onSpokenMessage("Vernie áll. Nincs folyamatban lévő feladat."); return; }
        if (paused) { listener.onSpokenMessage("A feladat már szünetel."); return; }
        handler.removeCallbacks(stepFinished);
        remainingMs = Math.max(0, remainingMs - (SystemClock.elapsedRealtime() - stepStartedAt));
        paused = true;
        listener.onSpokenMessage("Megálltam. Ha kéred, a félbehagyott lépés hátralévő részétől folytatom.");
    }

    void resume() {
        if (!running || !paused) { listener.onSpokenMessage("Nincs félbehagyott feladat, amit folytathatnék."); return; }
        if (!hub.isReady()) { listener.onSpokenMessage("Nem tudom folytatni, mert Vernie nincs csatlakoztatva."); return; }
        paused = false;
        listener.onState("Folytatom a félbehagyott feladatot.");
        startCurrentStep();
    }

    void cancel(boolean announce) {
        handler.removeCallbacks(stepFinished);
        if (hub.isReady()) hub.emergencyStop();
        steps = Collections.emptyList();
        running = false;
        paused = false;
        stepIndex = 0;
        remainingMs = 0;
        if (announce) listener.onSpokenMessage("A feladatot töröltem.");
    }

    void connectionLost() {
        if (running) cancel(false);
        listener.onSpokenMessage("Megszakadt a kapcsolat Vernie-vel, ezért a feladatot biztonsági okból töröltem.");
    }

    private void startCurrentStep() {
        Plan.Step step = steps.get(stepIndex);
        boolean accepted;
        switch (step.type) {
            case DRIVE: accepted = hub.drive(step.speed, step.speed); break;
            case TURN: accepted = hub.drive(step.speed, -step.speed); break;
            case WAIT: accepted = hub.emergencyStop(); break;
            default: accepted = false;
        }
        if (!accepted) {
            cancel(false);
            listener.onSpokenMessage("A feladatot nem tudtam folytatni, mert a motorparancs sikertelen volt.");
            return;
        }
        stepStartedAt = SystemClock.elapsedRealtime();
        handler.postDelayed(stepFinished, remainingMs);
        listener.onState("Lépés " + (stepIndex + 1) + "/" + steps.size());
    }

    private void finishCurrentStep() {
        if (!running || paused) return;
        hub.emergencyStop();
        stepIndex++;
        if (stepIndex >= steps.size()) {
            running = false;
            steps = Collections.emptyList();
            listener.onSpokenMessage("Kész vagyok.");
            return;
        }
        remainingMs = steps.get(stepIndex).durationMs;
        startCurrentStep();
    }
}
