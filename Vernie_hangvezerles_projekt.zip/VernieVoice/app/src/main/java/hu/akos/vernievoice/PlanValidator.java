package hu.akos.vernievoice;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

final class PlanValidator {
    static final int MAX_STEPS = 20;
    static final long MAX_STEP_MS = 10_000;
    static final long MAX_TOTAL_MS = 120_000;
    static final int MAX_SPEED = 60;

    private PlanValidator() {}

    static Plan parse(String json) throws JSONException {
        JSONObject root = new JSONObject(json);
        boolean accepted = root.getBoolean("accepted");
        String message = root.optString("message", "").trim();
        JSONArray rawSteps = root.getJSONArray("steps");
        if (rawSteps.length() > MAX_STEPS) throw new JSONException("Túl sok lépés.");

        ArrayList<Plan.Step> steps = new ArrayList<>();
        long total = 0;
        for (int i = 0; i < rawSteps.length(); i++) {
            JSONObject raw = rawSteps.getJSONObject(i);
            Plan.Type type;
            try { type = Plan.Type.valueOf(raw.getString("type")); }
            catch (IllegalArgumentException error) { throw new JSONException("Ismeretlen lépéstípus."); }
            int speed = raw.getInt("speed");
            long duration = raw.getLong("duration_ms");
            if (Math.abs(speed) > MAX_SPEED) throw new JSONException("Túl nagy sebesség.");
            if (duration < 100 || duration > MAX_STEP_MS) throw new JSONException("Érvénytelen lépéshossz.");
            if (type == Plan.Type.WAIT && speed != 0) throw new JSONException("A várakozás sebessége csak nulla lehet.");
            if (type != Plan.Type.WAIT && speed == 0) throw new JSONException("A mozgás sebessége nem lehet nulla.");
            total += duration;
            if (total > MAX_TOTAL_MS) throw new JSONException("A feladat túl hosszú.");
            steps.add(new Plan.Step(type, speed, duration));
        }
        if (accepted && steps.isEmpty()) throw new JSONException("Az elfogadott terv üres.");
        if (!accepted && message.isEmpty()) message = "Ezt a feladatot nem tudom biztonságosan végrehajtani.";
        return new Plan(accepted, message, steps);
    }
}
