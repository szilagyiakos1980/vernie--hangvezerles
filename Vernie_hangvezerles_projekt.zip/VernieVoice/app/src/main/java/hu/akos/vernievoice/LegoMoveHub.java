package hu.akos.vernievoice;

import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.os.Build;
import android.os.ParcelUuid;
import java.util.*;

final class LegoMoveHub {
    interface Listener {
        void onStatus(String text);
        void onDisconnected();
    }

    private static final UUID SERVICE = UUID.fromString("00001623-1212-efde-1623-785feabcd123");
    private static final UUID CHARACTERISTIC = UUID.fromString("00001624-1212-efde-1623-785feabcd123");
    private static final int LEFT_PORT = 0x37;
    private static final int RIGHT_PORT = 0x38;
    private final Context context;
    private final Listener listener;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic io;
    private BluetoothLeScanner scanner;
    private boolean scanning;
    private final ArrayDeque<byte[]> writeQueue = new ArrayDeque<>();
    private boolean writing;

    LegoMoveHub(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
    }

    @SuppressLint("MissingPermission")
    void connect() {
        disconnect();
        BluetoothManager manager = context.getSystemService(BluetoothManager.class);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null || !adapter.isEnabled()) {
            listener.onStatus("Kapcsold be a Bluetooth-t.");
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        ScanFilter filter = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SERVICE)).build();
        ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        scanning = true;
        listener.onStatus("Vernie keresése… Nyomd meg a hub zöld gombját!");
        scanner.startScan(Collections.singletonList(filter), settings, scanCallback);
    }

    @SuppressLint("MissingPermission")
    void disconnect() {
        if (scanning && scanner != null) scanner.stopScan(scanCallback);
        scanning = false;
        if (gatt != null) { gatt.disconnect(); gatt.close(); }
        gatt = null;
        io = null;
        synchronized (writeQueue) {
            writeQueue.clear();
            writing = false;
        }
    }

    @SuppressLint("MissingPermission")
    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (!scanning) return;
            scanner.stopScan(this);
            scanning = false;
            listener.onStatus("Hub megtalálva, kapcsolódás…");
            gatt = result.getDevice().connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        }
        @Override public void onScanFailed(int errorCode) {
            scanning = false;
            listener.onStatus("A keresés sikertelen (" + errorCode + ").");
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override public void onConnectionStateChange(BluetoothGatt value, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                listener.onStatus("Kapcsolódva, beállítás…");
                value.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                io = null;
                synchronized (writeQueue) {
                    writeQueue.clear();
                    writing = false;
                }
                listener.onStatus("Nincs kapcsolat Vernie-vel.");
                listener.onDisconnected();
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt value, int status) {
            BluetoothGattService service = value.getService(SERVICE);
            io = service == null ? null : service.getCharacteristic(CHARACTERISTIC);
            listener.onStatus(io == null ? "A hub nem támogatott." : "Vernie kapcsolódott — mondhatsz parancsot!");
        }
        @Override public void onCharacteristicWrite(BluetoothGatt value, BluetoothGattCharacteristic characteristic, int status) {
            synchronized (writeQueue) {
                writing = false;
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    writeQueue.clear();
                    listener.onStatus("A motorparancs Bluetooth-hibával leállt (" + status + ").");
                    return;
                }
                writeNext();
            }
        }
    };

    boolean isReady() { return gatt != null && io != null; }
    boolean forward() { return drive(55, 55); }
    boolean backward() { return drive(-55, -55); }
    boolean left() { return drive(-45, 45); }
    boolean right() { return drive(45, -45); }
    boolean stop() { return emergencyStop(); }

    boolean drive(int left, int right) {
        if (!isReady()) {
            listener.onStatus("Előbb csatlakozz Vernie-hez!");
            return false;
        }
        // A gyári Vernie-ben a két beépített motor tükörképesen áll.
        enqueuePower(LEFT_PORT, clamp(left));
        enqueuePower(RIGHT_PORT, clamp(-right));
        return true;
    }

    boolean emergencyStop() {
        if (!isReady()) return false;
        byte[] leftStop = powerCommand(LEFT_PORT, 0);
        byte[] rightStop = powerCommand(RIGHT_PORT, 0);
        synchronized (writeQueue) {
            writeQueue.clear();
            writeQueue.addFirst(rightStop);
            writeQueue.addFirst(leftStop);
            writeNext();
        }
        return true;
    }

    @SuppressLint("MissingPermission")
    private void enqueuePower(int port, int power) {
        byte[] command = powerCommand(port, power);
        synchronized (writeQueue) {
            writeQueue.add(command);
            writeNext();
        }
    }

    private static byte[] powerCommand(int port, int power) {
        return new byte[] { 0x08, 0x00, (byte)0x81, (byte)port, 0x11, 0x51, 0x00, (byte)power };
    }

    private static int clamp(int power) { return Math.max(-60, Math.min(60, power)); }

    @SuppressLint("MissingPermission")
    private void writeNext() {
        if (writing || writeQueue.isEmpty() || !isReady()) return;
        byte[] next = writeQueue.remove();
        if (Build.VERSION.SDK_INT >= 33) {
            int result = gatt.writeCharacteristic(io, next, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            writing = result == BluetoothStatusCodes.SUCCESS;
        } else {
            io.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            io.setValue(next);
            writing = gatt.writeCharacteristic(io);
        }
        if (!writing) {
            writeQueue.clear();
            listener.onStatus("A hub nem fogadta el a motorparancsot.");
        }
    }
}
