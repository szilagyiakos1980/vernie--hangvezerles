const MAX_COMMAND_CHARS = 500;

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["accepted", "message", "steps"],
  properties: {
    accepted: { type: "boolean" },
    message: { type: "string" },
    steps: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["type", "speed", "duration_ms"],
        properties: {
          type: { type: "string", enum: ["DRIVE", "TURN", "WAIT"] },
          speed: { type: "integer" },
          duration_ms: { type: "integer" }
        }
      }
    }
  }
};

export default {
  async fetch(request, env) {
    if (request.method !== "POST" || new URL(request.url).pathname !== "/plan") {
      return json({ error: "Not found" }, 404);
    }
    if (!env.OPENAI_API_KEY || !env.DEVICE_TOKEN) return json({ error: "Server not configured" }, 503);
    if (request.headers.get("Authorization") !== `Bearer ${env.DEVICE_TOKEN}`) return json({ error: "Unauthorized" }, 401);
    const declaredLength = Number(request.headers.get("Content-Length") || "0");
    if (declaredLength > 3000) return json({ error: "Request too large" }, 413);

    let body;
    try {
      const rawBody = await request.text();
      if (rawBody.length > 3000) return json({ error: "Request too large" }, 413);
      body = JSON.parse(rawBody);
    }
    catch { return json({ error: "Invalid JSON" }, 400); }
    const command = typeof body.command === "string" ? body.command.trim() : "";
    if (!command || command.length > MAX_COMMAND_CHARS) return json({ error: "Invalid command" }, 400);

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: env.OPENAI_MODEL || "gpt-5.6-luna",
        instructions: [
          "Te egy LEGO BOOST Vernie biztonsági feladattervezője vagy.",
          "A magyar utasítást csak DRIVE, TURN és WAIT lépésekre fordíthatod.",
          "DRIVE: pozitív előre, negatív hátra. TURN: pozitív jobbra, negatív balra. WAIT sebessége 0.",
          "Egy lépés legfeljebb 10 másodperc, a teljes terv legfeljebb 120 másodperc.",
          "Távolságot vagy szöget óvatos időbecsléssé alakíthatsz; ezt a message mezőben jelezd.",
          "Utasítsd el, ami szenzort, kamerát, tárgyfelismerést, megfogást, ugrást, lépcsőt, embert/állatot követő vagy veszélyes mozgást igényel.",
          "Ne állíts sikeres végrehajtást. A message legyen rövid, magyar és gyerekbarát."
        ].join(" "),
        input: command,
        max_output_tokens: 900,
        text: { format: { type: "json_schema", name: "vernie_plan", strict: true, schema } }
      })
    });
    if (!response.ok) return json({ error: "Planner unavailable" }, 502);
    const result = await response.json();
    const output = extractOutputText(result);
    if (typeof output !== "string") return json({ error: "Invalid planner response" }, 502);
    try {
      const plan = JSON.parse(output);
      if (!validPlan(plan)) return json({ error: "Unsafe planner response" }, 502);
      return json(plan, 200);
    } catch {
      return json({ error: "Invalid planner JSON" }, 502);
    }
  }
};

function extractOutputText(result) {
  if (typeof result.output_text === "string") return result.output_text;
  for (const item of result.output || []) {
    for (const content of item.content || []) {
      if (content.type === "output_text" && typeof content.text === "string") return content.text;
    }
  }
  return null;
}

function validPlan(plan) {
  if (!plan || typeof plan.accepted !== "boolean" || typeof plan.message !== "string" || !Array.isArray(plan.steps)) return false;
  if (plan.message.length > 240) return false;
  if (plan.steps.length > 20 || (plan.accepted && plan.steps.length === 0)) return false;
  let total = 0;
  for (const step of plan.steps) {
    if (!step || !["DRIVE", "TURN", "WAIT"].includes(step.type)) return false;
    if (!Number.isInteger(step.speed) || Math.abs(step.speed) > 60) return false;
    if (!Number.isInteger(step.duration_ms) || step.duration_ms < 100 || step.duration_ms > 10000) return false;
    if ((step.type === "WAIT") !== (step.speed === 0)) return false;
    total += step.duration_ms;
  }
  return total <= 120000;
}

function json(value, status) {
  return new Response(JSON.stringify(value), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
  });
}
