# Vernie hangvezérlés – biztonsági próbaverzió

Android-alkalmazás magyar, természetes nyelvű utasításokhoz és a gyári LEGO BOOST Vernie Move Hub közvetlen Bluetooth-vezérléséhez.

## Mi működik a forráskódban?

- szabadon megfogalmazott és összetett mondatok szerveroldali értelmezése;
- kizárólag ellenőrzött `DRIVE`, `TURN`, `WAIT` lépések;
- legfeljebb 60% motorteljesítmény, 10 másodperc/lépés, 120 másodperc/feladat és 20 lépés;
- azonnali, helyi „állj/stop/szünet”, folytatás a félbehagyott lépés hátralévő idejétől, valamint törlés;
- nagy képernyős vészleállító és csak rövid ideig működő kézi motorpróba;
- magyar hangos hiba- és állapotjelzés;
- API-kulcs nélküli APK: az OpenAI-kulcs csak a Worker titkai között van.

Ez még forráskód-szintű próbaverzió. Fizikai Vernie-n, az adott telefonon és valódi háttérszolgáltatással kötelező letesztelni; felügyelet nélküli használatra nem kész.

## APK letöltése GitHubról

A `.github/workflows/build-apk.yml` minden `main` ágra küldött változtatáskor automatikusan elkészíti a debug APK-t. A GitHubon nyisd meg az **Actions** fület, válaszd ki a legfrissebb sikeres **Vernie APK készítése** futást, majd az **Artifacts** részből töltsd le a `VernieVoice-debug-apk` csomagot. A letöltött ZIP-ben található az `app-debug.apk`.

## 1. Háttérszolgáltatás beállítása

A `server/worker.js` egy Cloudflare Worker példa. A `server` könyvtárban telepített Wranglerrel:

```bash
npx wrangler secret put OPENAI_API_KEY
npx wrangler secret put DEVICE_TOKEN
npx wrangler deploy
```

A `DEVICE_TOKEN` legyen hosszú, véletlen érték, és ne egyezzen az OpenAI-kulccsal. Állíts be az OpenAI-projektben havi költési korlátot, a Workernél pedig forgalmi/rate-limit szabályt. Az alkalmazásba kerülő eszköztoken kinyerhető az APK-ból, ezért önmagában nem pénzügyi szintű védelem; az igazi védelem a szerveroldali limit és a korlátozott OpenAI-projekt.

## 2. Android konfigurálása

Másold a `local.properties.example` fájlt `local.properties` néven, majd add meg:

```properties
vernie.backendUrl=
vernie.deviceToken=
```

OpenAI API-kulcsot ne tegyél a projektbe, a `local.properties` fájlba vagy az APK-ba.

Nyisd meg Android Studióban, telepítsd a telefonra, majd engedélyezd a mikrofont és a közeli Bluetooth-eszközöket. A hivatalos LEGO BOOST/Powered Up alkalmazás ne fusson közben.

## 3. Első biztonságos próba

1. Emeld fel úgy Vernie-t, hogy a kerekei szabadon foroghassanak.
2. Kapcsold be a Move Hubot, és nyomd meg a **Kapcsolódás** gombot.
3. A rövid kézi próbákkal ellenőrizd a motorirányokat.
4. Tedd akadálymentes, sík padlóra, távol lépcsőtől, embertől és állattól.
5. Indítsd a hangvezérlést, és próbáld: „Menj előre két másodpercig, fordulj balra, várj egy másodpercet, majd gyere vissza.”
6. Mozgás közben mondd: „állj”, majd „folytasd”.

Az Android beszédfelismerője nem garantáltan folyamatos vagy offline minden telefonon. A képernyős piros gomb ezért mindig elsődleges tartalék, de Bluetooth-kapcsolathiba esetén a mechanikus megoldás a Move Hub fizikai kikapcsolása.

## Tudatos korlátok

- A távolság és fordulási szög jelenleg időalapú becslés, nem pontos helymérés.
- Nincs még szenzor-, fejmotor-, kamera- vagy szobatérkép-kezelés.
- A rendszer nem igazolhatja érzékelő nélkül, hogy egy fizikai cél ténylegesen teljesült.
- A kamerás helymeghatározás külön fejlesztési fázis, nem része ennek az alkalmazásverziónak.
- Fordítási cél: Android SDK 35, Java 17, Android Gradle Plugin 8.9.1.
