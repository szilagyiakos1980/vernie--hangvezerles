# VernieVoice verzióelőzmény

## v0007 — 2026-09-10 20:42:36 CEST

Állapot: új, türkiz–zöld virtuális vezérlőpult és analóg joystick.

- A négy kézi iránygombot önközpontosító virtuális joystick váltotta fel.
- A joystick iránya és kitérése egyszerre szabályozza a két A/B hajtómotort és a sebességet.
- Elengedéskor vagy megszakadt érintéskor azonnali motorstop történik.
- Új, sötét türkiz–zöld műszerfal, térhatású gombok és kiemelt vészstop készült.
- Az Android alsó navigációs sávja immerzív módban rejtve marad; képernyőszéli húzással ideiglenesen előhívható.
- A felületi verziójelzés `v0007`, a belső Android-verzió `0.7`.

## Mentési szabály

- A `Vernie_hangvezerles_projekt.zip` a mindig friss főpéldány.
- Minden érdemi, működést befolyásoló módosítás után külön pillanatkép készül.
- Pillanatkép neve: `VernieVoice_vNNNN_ÉÉÉÉ-HH-NN_ÓÓ-PP-MP_CEST.zip`.
- A legnagyobb sorszám jelöli a legújabb mentést; egy sorszámot soha nem használunk fel újra.
- A dátum és idő magyarországi helyi idő.
- A GitHub `main` ágának commitjai további, fájlszintű visszaállítási pontok.
- Korábbi pillanatképet nem írunk felül és nem törlünk automatikusan.

## v0006 — 2026-09-10 19:16:26 CEST

Állapot: a négy kézi iránygomb nyomva tartásos vezérlésre módosítva.

- Lenyomáskor Vernie elindul a kiválasztott irányba.
- A gomb elengedésekor vagy az érintés megszakadásakor azonnali motorstop történik.
- A korábbi 1 másodperces előre/hátra és 0,7 másodperces fordulási időzítés megszűnt.
- A felületi verziójelzés `v0006`, a belső Android-verzió `0.6`.

## v0005 — 2026-09-10 19:13:02 CEST

Állapot: az eredeti Vernie A/B differenciálhajtására javítva, a felület kiegészítve.

- Bal hajtómotor: beépített A port (`0x00`).
- Jobb hajtómotor: beépített B port (`0x01`).
- Előremenetnél a tükörben beépített A/B motorok ellentétes nyers előjellel forognak.
- Balra és jobbra fordulásnál a két kerék ellentétes haladási irányt kap.
- A felületen megjelenik a verziószám és a frissítés időpontja.
- A teljes felület görgethető, így az alsó tájékoztató szöveg is elérhető.

## v0004 — 2026-09-10 18:40:58 CEST

Állapot: javítva a BOOST Move Hub beépített hajtómotorjainak portazonosítója.

- A hibás `0x37` és `0x38` érték helyett a C és D motorport `0x02` és `0x03` azonosítóját használjuk.
- Következő ellenőrzés: kerekei a levegőben, majd az ELŐRE kézi motorpróba.

## v0003 — 2026-09-10 18:11:07 CEST

Állapot: javítva a kapcsolódás után beragadó BLE motorparancssor.

- A LEGO 1624 karakterisztika most `WRITE_TYPE_NO_RESPONSE` módban kapja a parancsokat.
- A parancssor 35 ms-os ütemezéssel halad tovább, ezért az első biztonsági stop után is kiküldi a motorindítást.
- Következő ellenőrzés: Vernie kerekei a levegőben, majd a négy kézi iránygomb próbája.

## v0002 — 2026-09-10 17:43:44 CEST

Állapot: elkészült a Google Playen történő későbbi értékesítés kiadási terve.

- Új dokumentum: `GOOGLE_PLAY_KIADASI_TERV.md`.
- Rögzítve a fejlesztői fiók, tesztelés, AAB-kiadás és áruházi adatlap feladata.
- Rögzítve a gyermekvédelmi, mikrofon-, Bluetooth- és adatvédelmi követelmények.
- Javasolt üzleti modell: ingyenes alapváltozat, fizetős teljes hangértelmezés, ellenőrzött használati limitekkel.
- Rögzítve a LEGO/BOOST/Vernie megnevezések körültekintő, független termékként történő használata.
- Bevezetve a növekvő, négyjegyű verziószám a dátumbélyegző mellett.

## v0001 — 2026-09-10 16:46:06 CEST

Állapot: az első telepíthető debug APK sikeresen elkészült a GitHub Actions rendszerében.

- GitHub: https://github.com/szilagyiakos1980/vernie--hangvezerles
- Sikeres build commit: `ad7f86de190926cec08852465044f1887cfb620b`
- Javítva az Android 13+ Bluetooth `writeCharacteristic` API kompatibilitása.
- Működik az automatikus APK-fordítás a GitHubon.
- A telefonos telepítés megtörtént.
- A fizikai Vernie-kapcsolat és motorirányok tesztje még hátravan.
- OpenAI API és háttérszolgáltatás még nincs beállítva.

## Visszaállítás

Visszaállításkor először a kívánt dátumbélyeges ZIP-et kell kiválasztani. A ZIP teljes projektállapotot tartalmaz. GitHubon finomabb visszaállításhoz a megfelelő commit használható.
