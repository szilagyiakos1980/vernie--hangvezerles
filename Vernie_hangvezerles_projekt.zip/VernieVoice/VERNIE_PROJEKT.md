# Vernie hangvezérlés és későbbi térbeli navigáció

## Eredeti cél

Önálló Android-alkalmazás, amely magyarul, természetes módon bemondott utasításokat értelmez, és Bluetoothon közvetlenül vezérli az összeszerelt LEGO BOOST Vernie Move Hubját. Nem grafikus LEGO-program, és a hivatalos LEGO-alkalmazásnak nem kell közben futnia.

## Elfogadott követelmények

- Ne fix mondatlista legyen: szabad megfogalmazást és összetett lépéssort is értelmezzen.
- A végrehajtás bármikor legyen megszakítható.
- A „folytasd” a félbehagyott lépés hátralévő részétől folytasson.
- A feladat végleg törölhető legyen.
- Ha valami nem hajtható végre, Vernie magyar hangon mondja el az okát.
- Legyen képernyős azonnali vészleállítás.
- Az alkalmazás ne állítson érzékelő nélküli fizikai sikert.
- Az OpenAI API-kulcs ne kerüljön az APK-ba.

## A mostani próbaverzió felépítése

1. Az Android magyar beszédfelismerése szöveget készít.
2. Az „állj/stop/szünet”, „folytasd/tovább” és „töröld” helyben fut, API-válasz nélkül.
3. Más mondatot a védett Worker küld a GPT-5.6 Luna modellnek.
4. A modell szigorú JSON-séma szerint csak `DRIVE`, `TURN`, `WAIT` lépéssort adhat.
5. A Worker és az Android is újra ellenőrzi a tervet.
6. A feladatmotor időzíti, szünetelteti, folytatja vagy törli a lépéseket.
7. Az alkalmazás LEGO Wireless Protocol motorparancsokat küld BLE-n.

## Beépített biztonsági korlátok

| Korlát | Érték |
|---|---:|
| Maximális motorteljesítmény | 60% |
| Egy lépés maximuma | 10 másodperc |
| Egy feladat maximuma | 120 másodperc |
| Lépések maximális száma | 20 |
| Parancsszöveg maximuma | 500 karakter |

További védelem:

- a piros vészgomb és a helyi stop nem vár az internetre;
- a stop kiüríti a még el nem küldött BLE-motorparancsokat;
- háttérbe kerüléskor az alkalmazás törli a futó feladatot és megállítja Vernie-t;
- megszakadt kapcsolatnál a feladat törlődik;
- egy stop után későn visszaérkező AI-válasz már nem indíthatja el a robotot;
- a kézi iránygombok csak rövid motorpróbát indítanak;
- az OpenAI-kulcs kizárólag szerveroldali titok.

Fontos: Bluetooth-hiba esetén egy telefonos stop sem ad abszolút fizikai garanciát. Gyerek csak felnőtt felügyeletével használja, sík, akadálymentes helyen, lépcsőtől, embertől és állattól távol. Végső leállítás a Move Hub fizikai kikapcsolása.

## Mit tud és mit nem tud most?

| Terület | Állapot |
|---|---|
| BLE-keresés és Move Hub-kapcsolódás | implementálva, hardveren tesztelendő |
| Két beépített motor vezérlése | implementálva, irányt hardveren kalibrálni kell |
| Magyar beszédfelismerés | implementálva, telefonfüggő |
| Szabad nyelvű értelmezés | implementálva a Workerrel, beállítás és élő API-próba kell |
| Összetett időzített lépések | implementálva |
| Pontos szünet/folytatás | implementálva időalapon |
| Hangos hibajelzés | implementálva |
| Szenzorok, fejmozgatás, táncok | még nincs implementálva |
| Kamerás szobanavigáció | későbbi külön fázis |

## API, előfizetés és költség

- Nem kell külön ChatGPT-előfizetés; az API külön, használatalapú szolgáltatás.
- A terv GPT-5.6 Luna modellt használ. A modell a Worker `OPENAI_MODEL` változójával cserélhető.
- A költség tokenfüggő, nem a mikrofon bekapcsolva töltött perceitől függ, mert a beszédfelismerést a telefon végzi.
- Az „5 USD = 20–40 ezer parancs” csak durva korábbi becslés volt, nem garancia. A valódi parancsonkénti tokenhasználatot az API Usage oldalon kell megmérni.
- Gyerekek intenzív használatánál kötelező az OpenAI-projekt költési korlátja és a Worker forgalmi korlátozása. Az automatikus feltöltés csak tudatos döntéssel legyen bekapcsolva.

## Gyerekeknek szánt következő funkciók

- humoros Vernie-személyiség és név szerinti köszöntés;
- előre ellenőrzött tánc- és küldetéscsomagok;
- színküldetések és akadályérzékelős játék a gyári érzékelőkkel;
- teljesítményjelvények és választható hangstílus;
- szenzorbemenetre épülő őrjárat és játékok.

Ezek előtt szükséges a csatlakoztatott portok és érzékelők biztos felismerése, valamint minden mozgásra külön biztonsági határ.

## Térbeli tájékozódás

Első szintként kerékelfordulásból becsült helyzet, távolságérzékelős ütközésmegelőzés és színes padlójelölők jöhetnek. A kerékcsúszás miatt ez hosszabb úton eldriftel.

A későbbi kamerás változatban a szobát telefonnal előre fel lehet térképezni, Vernie pedig könnyű Wi-Fi-kamerát kaphat. A kameraképet a korábbi térképhez illesztő vizuális lokalizáció, kerékadat és 2–4 AprilTag együtt adhat használható helybecslést. Ez külön számítógépes látási rendszer; a mostani próbaverzió nem tartalmazza. Bizonytalan helyzetnél Vernie-nek meg kell állnia és jeleznie kell, hogy elvesztette a pozícióját.

## Következő ellenőrzési sorrend

1. Android Studio fordítás és telepítés.
2. Kerekek levegőben: motorportok és előjelek ellenőrzése.
3. Vészgomb, háttérbe küldés és Bluetooth-szakadás próbája.
4. Szünet/folytatás mérése több lépés közepén.
5. Worker telepítés, titkok, költési és forgalmi limit.
6. Elfogadott, elutasított, túl hosszú és rossz formátumú AI-tervek tesztje.
7. Csak ezután felügyelt padlóteszt gyerekekkel.

## Hivatkozások

- OpenAI API árak: https://developers.openai.com/api/docs/pricing
- Strukturált kimenetek: https://developers.openai.com/api/docs/guides/structured-outputs
- API-hitelesítés és kulcsbiztonság: https://developers.openai.com/api/reference/overview
- LEGO Wireless Protocol: https://lego.github.io/lego-ble-wireless-protocol-docs/
- ORB-SLAM3: https://arxiv.org/abs/2007.11898
- AprilTag: https://april.eecs.umich.edu/
