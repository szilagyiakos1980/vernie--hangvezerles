# VernieVoice – Google Play kiadási és értékesítési terv

Mentés: **v0002 — 2026-09-10 17:43:44 CEST**

## Cél

Ha az alkalmazás a fizikai LEGO BOOST Vernie robottal végzett próbákon stabilnak és biztonságosnak bizonyul, később a Google Play Áruházban is megjelenhet. Először zárt, 10–20 családos béta teszt javasolt, és csak a hibák kijavítása után fizetős kiadás.

## Kiadási lépések

1. Google Play Console fejlesztői fiók létrehozása. Ennek jelenlegi regisztrációs díja egyszeri 25 USD; személyes és szervezeti fiók választható.
2. Személyazonosság és – új személyes fióknál – Android-eszköz ellenőrzése.
3. Végleges alkalmazásnév, ikon, egyedi csomagnév és kiadási aláírás beállítása.
4. A debug APK helyett aláírt Android App Bundle (AAB) készítése, Play App Signing használatával.
5. Új személyes fejlesztői fióknál a Google által előírt zárt teszt teljesítése. A 2026. szeptemberi szabály szerint legalább 12 tesztelőnek 14 egymást követő napon részt kell vennie; közzététel előtt ezt újra ellenőrizni kell.
6. Áruházi adatlap elkészítése: magyar és angol leírás, ikon, képernyőképek, kiemelt grafika, kapcsolattartási cím és támogatási oldal.
7. Adatbiztonsági, célközönség- és korhatár-kérdőív kitöltése, majd beküldés ellenőrzésre.

## Gyermekvédelem és adatkezelés

- Pontosan közölni kell a mikrofon, a Bluetooth és az OpenAI felé továbbított hang- vagy szövegadat használatát.
- Az adatvédelmi tájékoztatónak az alkalmazásban és nyilvános webcímen is elérhetőnek kell lennie.
- Csak a feltétlenül szükséges jogosultságokat szabad kérni.
- Gyermekeknek szánt alkalmazásnál a Google Families szabályai, a GDPR és az alkalmazandó gyermekvédelmi előírások betartandók.
- A Bluetooth-párosítást a kiadás előtt felül kell vizsgálni a Companion Device Manager követelménye szerint.
- Az OpenAI API-kulcs soha nem kerülhet az alkalmazásba; a kérések védett háttérszolgáltatáson keresztül menjenek.
- Szülői beállítások, költési limit, használati limit és azonnali vészleállítás szükséges.

## Javasolt értékesítési modell

- Az alkalmazás ingyenesen letölthető, korlátozott bemutató móddal.
- A teljes természetes nyelvű hangvezérlés egyszeri vásárlással vagy előfizetéssel aktiválható.
- Az OpenAI használati költségét az árba és a felhasználónkénti limitekbe bele kell számítani.
- Digitális értékesítésnél a Google szolgáltatási díjával is számolni kell; a jogosult fejlesztőknél ez jellemzően 15% az első évi 1 millió USD bevételig.
- Gyerekeknek szánt első kiadásban reklámok használata nem javasolt.

## Márkanév

A LEGO, BOOST és Vernie megnevezések védett márkák lehetnek. A terméket célszerű saját márkanéven kiadni, és jól láthatóan közölni, hogy független alkalmazás, amelyet a LEGO Group nem támogatott és nem hagyott jóvá. A végleges név és áruházi szöveg kiadás előtt jogi ellenőrzést igényelhet.

## Közzététel előtti döntési kapuk

- Valódi Vernie hardveren stabil csatlakozás és motorvezérlés.
- Megbízható megszakítás, folytatás, vészleállítás és Bluetooth-szakadás kezelése.
- Több telefonon és Android-verzión sikeres teszt.
- Biztonsági és adatvédelmi átvizsgálás.
- API-költségmérés valós gyermekhasználati mintával.
- Béta tesztelői hibák lezárása.
- Google Play aktuális szabályainak ismételt ellenőrzése közvetlenül a beadás előtt.

## Hivatalos hivatkozások

- Fejlesztői fiók: https://support.google.com/googleplay/android-developer/answer/6112435?hl=en
- Alkalmazás feltöltése: https://developer.android.com/studio/publish/upload-bundle
- Ellenőrzésre felkészítés: https://support.google.com/googleplay/android-developer/answer/9859455?hl=en
- Families szabályzat: https://support.google.com/googleplay/android-developer/answer/9893335?hl=en
- Szolgáltatási díjak: https://support.google.com/googleplay/android-developer/answer/112622?hl=en

> A díjak és szabályok változhatnak; a fenti állapot 2026. szeptember 10-én volt ellenőrizve.
